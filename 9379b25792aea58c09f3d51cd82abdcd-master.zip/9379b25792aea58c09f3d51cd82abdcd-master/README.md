
## Use basic p5.play-boilerplate
Boiler plate for p5.play : https://github.com/vishnupriya-whitehatjr/BasicLibFiles

## Please refer to code notes for explanation.

### Output Link : https://vishnupriya-whitehatjr.github.io/c33-PlinkoFinal/index.html
